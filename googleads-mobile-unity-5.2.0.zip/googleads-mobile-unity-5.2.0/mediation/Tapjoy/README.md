# Tapjoy Adapter plugin for Google Mobile Ads SDK for Unity 3D

This is a plugin to be used in conjunction with the Google Mobile Ads SDK in
Google Play services. For requirements, instructions, and other info, see the
[Tapjoy Adapter Integration Guide](https://developers.google.com/admob/unity/mediation/tapjoy).

