## i-mobile Unity Mediation Plugin Changelog

#### Version 1.0.2
- Supports [i-mobile Android adapter version 2.0.22.0](https://github.com/googleads/googleads-mobile-android-mediation/blob/master/ThirdPartyAdapters/imobile/CHANGELOG.md#version-20220).
- Supports [i-mobile iOS adapter version 2.0.32.0](https://github.com/googleads/googleads-mobile-ios-mediation/blob/master/adapters/I-Mobile/CHANGELOG.md#version-20320).

#### Version 1.0.1
- Supports [i-mobile Android adapter version 2.0.21.0](https://github.com/googleads/googleads-mobile-android-mediation/blob/master/ThirdPartyAdapters/imobile/CHANGELOG.md#version-20210).
- Supports [i-mobile iOS adapter version 2.0.31.0](https://github.com/googleads/googleads-mobile-ios-mediation/blob/master/adapters/I-Mobile/CHANGELOG.md#version-20310).

#### Version 1.0.0
- First release!
- Supports [i-mobile Android adapter version 2.0.20.1](https://github.com/googleads/googleads-mobile-android-mediation/blob/master/ThirdPartyAdapters/imobile/CHANGELOG.md#version-20201).
- Supports [i-mobile iOS adapter version 2.0.29.0](https://github.com/googleads/googleads-mobile-ios-mediation/blob/master/adapters/I-Mobile/CHANGELOG.md#version-20290).
