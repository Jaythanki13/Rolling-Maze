// Copyright 2017 Google Inc. All Rights Reserved.

#import <Foundation/Foundation.h>

#import <GoogleMobileAds/GoogleMobileAds.h>

#import "GADUAdNetworkExtras.h"

@interface VungleExtrasBuilder : NSObject<GADUAdNetworkExtras>

@end
