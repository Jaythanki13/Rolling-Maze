﻿// Copyright 2018 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using UnityEngine;

using GoogleMobileAds.Common.Mediation.MyTarget;
using GoogleMobileAds.Mediation;

namespace GoogleMobileAds.Api.Mediation.MyTarget
{
    public class MyTarget
    {
        public static readonly IMyTargetClient client = GetMyTargetClient();

        private static IMyTargetClient GetMyTargetClient()
        {
            return MyTargetClientFactory.MyTargetInstance ();
        }

        public static void SetUserConsent(bool userConsent)
        {
            client.SetUserConsent (userConsent);
        }

        public static void SetUserAgeRestricted(bool userAgeRestricted)
        {
            client.SetUserAgeRestricted (userAgeRestricted);
        }

        public static bool IsUserConsent()
        {
            return client.IsUserConsent ();
        }

        public static bool IsUserAgeRestricted()
        {
            return client.IsUserAgeRestricted ();
        }
    }
}
